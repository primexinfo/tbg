export const CLIENT_URL = "https://tb.primex-bd.com/wp/graphql";
export const SYSTEM_URL = "https://tb.primex-bd.com/wp/graphql"; //dev_url