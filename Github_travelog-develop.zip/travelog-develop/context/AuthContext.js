import { createContext } from "react";
export const AuthContext = createContext(null); // not used anywhere yet

