const theme = {
    colors: {
      primary: '#ffffff',
      blackish: '#b7b7b7',
    },
}

export default theme